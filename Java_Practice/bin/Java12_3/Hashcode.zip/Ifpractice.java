package Java12_3;
import java.util.Scanner;
public class Ifpractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        //monster_hp = 100   sword_ATTK = 10  AXE_ATTX = 12 Hammer_ATTK = 11 Poison +2
		
		Scanner sc = new Scanner (System.in);
		//System.out.println("텍스트를 입력하세요");
		String a = "안녕하세요";
		String b = "안녕하세요";
		//String b = new String("안녕하세요");
		//String s = sc.next();    // 글자 받는 것
		//if (s.
		//System.out.println(a);   // 받은 글자를 입력 다시 입력하는 것
		if(a.equals(b)) {
			System.out.println("둘은 같다");
		}
		else {
			System.out.println("같지 않다");
		}
		//String str = ""
		
	}

}
