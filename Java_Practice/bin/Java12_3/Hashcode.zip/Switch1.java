package Java12_3;
import java.util.Scanner;
public class Switch1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
		String year1 ="";
		System.out.println("출생연도를 입력하세요");
		int year = sc.nextInt();
		
		if (year%12==0) {
			System.out.println("원숭이띠");
		}
		if (year%12==1) {
			System.out.println("닭띠");
		}
		if (year%12==2) {
			System.out.println("개띠");
		}
		if (year%12==3) {
			System.out.println("돼지띠");
		}
		if (year%12==4) {
			System.out.println("쥐띠");
		}
		if (year%12==5) {
			System.out.println("소띠");
		}
		if (year%12==6) {
			System.out.println("호랑이띠");
		}
		if (year%12==7) {
			System.out.println("토끼띠");
		}
		if (year%12==8) {
			System.out.println("용띠");
		}
		if (year%12==9) {
			System.out.println("뱀띠");
		}
		if (year%12==10) {
			System.out.println("말띠");
		}
		if (year%12==11) {
			System.out.println("양띠");
		}
		
		
		
		
//		switch(year%12) {
//		case 0 : System.out.println("원숭이띠");
//		break;
//		case 1 : System.out.println("닭띠");
//		break;
//		case 2 : System.out.println("개띠");
//		break;
//		case 3 : System.out.println("돼지띠");
//		break;
//		case 4 : System.out.println("쥐띠");
//		break;
//		case 5 : System.out.println("소띠");
//		break;
//		case 6 : System.out.println("호랑이띠");
//		break;
//		case 7 : System.out.println("토끼띠");
//		break;
//		case 8: System.out.println("용띠");
//		break;
//		case 9 : System.out.println("뱀띠");
//		break;
//	    case 10 : System.out.println("말띠");
//		break;
//		case 11 : System.out.println("양때");
//		break;
//		
//			
//		}
//		
		
		
		
		
		
	}

}
